BEYOND TATTOO - STENCIL OF THE DAY
Eye of Horus Anubis - Beyond Ancient Collection
Thursday, July 16, 2026

Included:
- Artist preview WebP
- Printer-ready transfer PNG
- Letter-size transfer PDF
- Transfer SVG
- Editable SVG master
- Studio placement guide PDF with suggested sizing
- Metadata JSON

Suggested best fit: outer forearm, 6.5-8.5 inches tall.
Alternative placements: upper arm/shoulder, outer calf, or upper back/shoulder blade.

Free stencil drop. Verify final scale, orientation, body flow, and placement before transfer.
